import streamlit as st
import requests
import math
import openai
from transformers import pipeline
import os
from dotenv import load_dotenv
load_dotenv()
#CONFIG
SERPAPI_KEY = os.getenv("SERPAPI_KEY")
openai.api_key = os.getenv("OPENAI_API_KEY")

#FUNCTIONS
def get_products(query):
    params = {
        "engine": "google_shopping",
        "q": query,
        "api_key": SERPAPI_KEY,
        "gl": "IN",
        "hl": "en",
        "google_domain": "google.co.in"
    }
    response = requests.get("https://serpapi.com/search", params=params)
    if response.status_code == 200:
        return response.json().get("shopping_results", [])
    return []

def get_user_location():
    try:
        res = requests.get("https://ipinfo.io", timeout=5)
        if res.status_code == 200:
            data = res.json()
            city = data.get("city", "")
            region = data.get("region", "")
            location = ", ".join(filter(None, [city, region]))
            return location if location else "India"
    except:
        pass
    return "India"  

@st.cache_resource
def get_classifier():
    return pipeline("zero-shot-classification", model="facebook/bart-large-mnli")

def is_food_query_nlp(query):
    classifier = get_classifier()
    candidate_labels = ["food", "electronics", "clothing", "furniture", "medicine", "books"]
    result = classifier(query, candidate_labels)
    top_label = result["labels"][0]
    return top_label == "food"

def get_local_food_results(query, location):
    params = {
        "engine": "google_maps",
        "q": f"{query} food delivery in {location}",
        "api_key": SERPAPI_KEY,
        "hl": "en"
    }
    response = requests.get("https://serpapi.com/search", params=params)
    if response.status_code == 200:
        places = response.json().get("local_results", [])
        results = []
        for p in places:
            results.append({
                'title': p.get('title', 'N/A'),
                'link': p.get('link', '#'),
                'address': p.get('address', 'N/A'),
                'rating': p.get('rating', 'N/A'),
                'reviews': p.get('reviews', 'N/A'),
            })
        return results
    return []


def parse_price(price_str):
    try:
        return float(price_str.replace("₹", "").replace(",", "").strip())
    except:
        return 0.0

def parse_reviews(reviews_str):
    try:
        return int(reviews_str.replace(",", "").strip())
    except:
        return 0

def build_prompt(user_query, products):
    prices = [p['price'] for p in products]
    max_price = max(prices) if prices else 1

    product_lines = []
    for i, p in enumerate(products, start=1):
        price_val = p['price']
        rating_val = float(p.get('rating', 0))
        reviews_val = p.get('reviews', '0')
        title = p.get('title', 'No Title')

        product_lines.append(
            f"{i}. Title: {title}\n"
            f"   Price: {price_val}\n"
            f"   Rating: {rating_val}\n"
            f"   Reviews: {reviews_val}\n"
        )

    product_text = "\n".join(product_lines)

    prompt = (
        f"User query: '{user_query}'\n\n"
        f"Here are product options:\n\n"
        f"{product_text}\n"
        f"Rank all the products using this formula:\n\n"
        f"Rank Score = (w_rel × normalized_relevance) + (w_r × normalized_rating) + "
        f"(w_n × normalized_reviews) - (w_p × normalized_price)\n\n"
        f"Where:\n"
        f"- normalized_relevance = AI-inferred relevance (0 to 1)\n"
        f"- normalized_rating = Rating / 5\n"
        f"- normalized_reviews = log₁₀(Reviews + 1)\n"
        f"- normalized_price = √price / √{max_price}\n"
        f"- w_rel = 0.7\n"
        f"- w_r = 0.4\n"
        f"- w_n = 0.4\n"
        f"- w_p = 0.2\n\n"
        f"Requirements:\n"
        f"- Show a rank table with computed scores\n"
        f"- Explain each ranking with clarity, considering rating, reviews, price, and brand credibility\n"
        f"- Sort from highest to lowest score\n"
    )
    return prompt

def rank_products_with_gpt(user_query, products):
    prompt = build_prompt(user_query, products)

    response = openai.chat.completions.create(
        model="gpt-4o",
        messages=[
            {
                "role": "system",
                "content": (
                    "You are an expert product recommendation assistant. Your job is to evaluate "
                    "and rank shopping products based on customer reviews, price, and compute the relevance of product title"
                    "to the user's query. You must explain your reasoning clearly and compute scores using a specific formula. "
                    "Always include a rank table followed by detailed reasoning."
                ),
            },
            {"role": "user", "content": prompt},
        ],
    )
    reasoning = response.choices[0].message.content
    return reasoning

def extract_top10_titles_from_reasoning(reasoning, products):
    import re
    ranked_titles = []
    lines = reasoning.split("\n")
    rank_line_pattern = re.compile(r"^\s*\d+\.\s*Title:\s*(.*)", re.IGNORECASE)
    for line in lines:
        match = rank_line_pattern.match(line)
        if match:
            title = match.group(1).strip()
            ranked_titles.append(title)
        if len(ranked_titles) >= 10:
            break

    top_products = []
    for title in ranked_titles:
        for p in products:
            if title.lower() in p['title'].lower():
                top_products.append(p)
                break
    return top_products[:10]

def get_ingredients(user_query, is_food):
    if not is_food:
        return []

    prompt = f"Mention only the ingredients too cook {user_query}, one ingredient per line, no other text."

    response = openai.chat.completions.create(
        model="gpt-4o", 
        messages=[
            {"role": "system", "content": prompt}
        ]
    )
    answer = response.choices[0].message.content.strip()
    ingredients = [line.strip("-• ").strip() for line in answer.splitlines() if line.strip()]
    return ingredients

#Streamlit
st.title("🛍️ Product Recommender")

user_query = st.text_input("What product are you looking for?")

if st.button("Search") and user_query:
    with st.spinner("Analyzing your query..."):
        is_food = is_food_query_nlp(user_query)

    if is_food:
        # --- Food flow ---
        with st.spinner("📍 Detecting your location..."):
            user_location = get_user_location()
        st.caption(f"Detected location: {user_location}")

        with st.spinner(f"🍽️ Searching for '{user_query}' food delivery near you..."):
            food_places = get_local_food_results(user_query, user_location)

        if not food_places:
            st.error("No food delivery options found in your area.")
        else:
            st.success(f"Found {len(food_places)} food delivery options near {user_location}!")
            st.markdown("### 🍽️ Available Food Delivery Options")
            for i, place in enumerate(food_places):
                st.markdown(f"**{i+1}. [{place['title']}]({place['link']})**")
                st.caption(f"📍 Address: {place['address']}")
                st.caption(f"⭐ Rating: {place['rating']} ({place['reviews']} reviews)")
                st.markdown("---")

            search_term = user_query.replace(" ", "+")
            city_slug = user_location.lower().replace(" ", "-")
            swiggy_url = f"https://www.swiggy.com/search?query={search_term}"
            zomato_url = f"https://www.zomato.com/{city_slug}/restaurants?q={search_term}"

            st.markdown("### 🔗 Try Also on Popular Food Platforms")
            st.markdown(f"- 🍛 [Search on Swiggy](<{swiggy_url}>)")
            st.markdown(f"- 🍕 [Search on Zomato](<{zomato_url}>)")
            st.markdown('### Ingredients')
            ingredients = get_ingredients(user_query, True)

            if ingredients:
                st.markdown("### 🧂 Ingredients")
                for ing in sorted(ingredients):
                    st.markdown(f"- {ing}")
                shopping_query = "buy " + ", ".join(ingredients)
                # Step 3: Get product results from SerpAPI
                products = get_products(shopping_query)
                if products:
                    st.markdown("### 🛒 Online stores delivering these ingredients:")
                    for p in products:
                        title = p.get("title", "No title")
                        price = p.get("price", "Price not available")
                        store = p.get("source", "Unknown store")
                        link = p.get("product_link", "#")
                        
                        st.markdown(f"**{title}** - {price} from *{store}*")
                        st.markdown(f"[Buy here]({link})")
                        st.markdown("---")
                else:
                    st.info("No deliverable products found for these ingredients.")
            else:
                    st.info("Couldn't extract ingredients from your query.")

    else:
        with st.spinner("Searching for products..."):
            products = get_products(user_query)

        if not products:
            st.error("No products found.")
        else:
            cleaned_products = []
            for product in products:
                title = product.get('title', 'No Title')
                price_str = product.get('price', '₹0')
                rating = float(product.get('rating', 0)) if product.get('rating') else 0.0
                num_reviews = product.get('reviews', '0')
                link = product.get('product_link', '') or product.get('link', '')
                source = product.get('source', '')
                thumbnail = product.get('thumbnail', '')

                cleaned_products.append({
                    'title': title,
                    'price': price_str,
                    'rating': rating,
                    'reviews': num_reviews,
                    'link': link,
                    'source': source,
                    'thumbnail': thumbnail,
                })

            st.markdown("### 🔎 All Products from SerpAPI Search:")
            for i, product in enumerate(cleaned_products, start=1):
                st.markdown(f"**{i}. [{product['title']}]({product['link']})**")
                st.write(
                    f"⭐ Rating: {product['rating']} | "
                    f"🗨️ Reviews: {product['reviews']} | "
                    f"💰 Price: {product['price']} | "
                    f"🏪 Source: {product['source']}"
                )
                if product['thumbnail']:
                    st.image(product['thumbnail'], width=150)
                st.markdown("---")

            with st.spinner("🤖 AI thinking... check terminal for reasoning..."):
                reasoning = rank_products_with_gpt(user_query, cleaned_products)
                print("\n--- AI Product Reasoning (Top 10 Products Ranking) ---\n")
                print(reasoning)
                print("\n-----------------------------------------------------\n")

            top_10_products = extract_top10_titles_from_reasoning(reasoning, cleaned_products)
            st.markdown("### 🏆 Top 10 Recommended Products:")

            for i, product in enumerate(top_10_products, start=1):
                st.markdown(f"**{i}. [{product['title']}]({product['link']})**")
                st.write(
                    f"⭐ Rating: {product['rating']} | "
                    f"🗨️ Reviews: {product['reviews']} | "
                    f"💰 Price: {product['price']} | "
                    f"🏪 Source: {product['source']}"
                )
                if product['thumbnail']:
                    st.image(product['thumbnail'], width=150)
                st.markdown("---")




